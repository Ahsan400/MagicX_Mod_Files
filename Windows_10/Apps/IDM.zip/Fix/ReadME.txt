===================
-:[Install Notes]:-
===================
==> Install Program
==> When Finish Installation, Close Program Totally (Exit "Tray Icon" From Taskbar)
==> Copy Patch and paste to the software install directory and apply it
==> Don't Update the Program & Enjoy ...
